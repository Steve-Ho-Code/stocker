# Comprehensive Project Guide: From Zero to Production

This guide provides a complete, step-by-step walkthrough for setting up, running, testing, and deploying the Stocker project. It is designed to be clear enough for users with a basic understanding of the command line.

### Deployment Strategy: Cloud-First, Local-Ready

This project is architected around Docker containers, making it highly portable. The primary and recommended deployment path is a **cloud-based Virtual Private Server (VPS)**, which ensures 24/7 availability and high performance. This guide focuses on that path.

However, the same Docker-based setup can be used on a local home server (like an N100 Mini PC) with almost no changes. This provides the flexibility to migrate from a cloud VPS to a home server in the future if desired. The core steps of cloning the repository, setting up the `.env` file, and running `docker-compose` remain the same regardless of the environment.

---

## Part 1: Initial Environment Setup (The "Zero")

This section covers how to get a clean development environment ready on your local machine.

### 1.1. Core Dependencies

Before you begin, you need to install four essential tools. Please follow the official installation instructions for your operating system.

*   **Git:** For version control. We'll use it to download the code.
    *   [Official Guide](https://git-scm.com/book/en/v2/Getting-Started-Installing-Git)
*   **Python:** We use Python 3.10 or higher.
    *   [Official Website](https://www.python.org/downloads/)
*   **Docker & Docker Compose:** This is the most critical piece. It allows us to run the application and its database/cache services in isolated containers. It is **highly recommended** to install **Docker Desktop** for your OS, as it includes both Docker and Docker Compose.
    *   [Official Guide](https://docs.docker.com/get-docker/)
*   **Poetry:** This tool manages the specific Python libraries our project needs.
    *   [Official Guide](https://python-poetry.org/docs/#installation)
    *   On macOS/Linux, the recommended command is usually:
        ```bash
        curl -sSL https://install.python-poetry.org | python3 -
        ```

### 1.2. Cloning the Repository

Once the core dependencies are installed, open your terminal, navigate to a directory where you want to store the project, and run the following commands to download the code and enter the project folder.

```bash
git clone https://github.com/your-username/stocker.git
cd stocker
```

### 1.3. Acquiring Secrets and IDs

Before we can run the project, we need to gather some essential credentials. 

1.  **Telegram Bot Token (`API_TOKEN`):**
    *   Open Telegram and search for the user `BotFather` (it has a blue checkmark).
    *   Start a chat and type `/newbot`.
    *   Follow the prompts. Give your bot a name and a username.
    *   `BotFather` will reply with a long string of characters. This is your `API_TOKEN`. Copy it.

2.  **Channel ID (`CHANNEL_ID`):
    *   Create a new **public** Telegram channel.
    *   The channel ID is simply its username, including the `@` symbol (e.g., `@my_stocker_channel`).

3.  **Super Admin Telegram ID (`SUPER_ADMIN_TELEGRAM_ID`):
    *   On Telegram, search for the user `userinfobot`.
    *   Start a chat and it will immediately reply with your User ID. This is a number. Copy it.

4.  **Financial API Key (`FINANCIAL_API_KEY`):
    *   This project is configured to use [Alpha Vantage](https://www.alphavantage.co/).
    *   Go to their website and claim your free API key.

### 1.4. Environment Configuration

Now we will create a `.env` file to securely store the credentials we just gathered.

1.  **Create the `.env` file:**
    In your terminal, at the root of the `stocker` project, run:
    ```bash
    cp .env.example .env
    ```

2.  **Edit the `.env` file:**
    Open the newly created `.env` file with any text editor and paste the values you copied.

    ```dotenv
    API_TOKEN="PASTE_YOUR_TELEGRAM_BOT_TOKEN_HERE"
    CHANNEL_ID="@your_channel_name"
    FINANCIAL_API_KEY="PASTE_YOUR_ALPHA_VANTAGE_KEY_HERE"
    SUPER_ADMIN_TELEGRAM_ID="PASTE_YOUR_TELEGRAM_ID_HERE"

    # These values are pre-configured for the docker-compose setup. Do not change them for local development.
    DATABASE_URL="postgresql://user:password@db:5432/stocker"
    REDIS_URL="redis://redis:6379"
    ```
    **Note:** I have updated the `DATABASE_URL` and `REDIS_URL` to use the service names (`db`, `redis`) defined in `docker-compose.yml`. This is the correct way for containers to communicate with each other.

**At this point, your local environment is fully configured.**

---

## Part 2: Running the Project with Docker (The "50")

This is the **recommended** way to run the project. It ensures that the application, database, and cache all run in a consistent, isolated environment.

### 2.1. Building and Running the Services

With Docker Desktop running on your machine, navigate to the root of the project directory and run:

```bash
docker-compose up --build
```

*   **What's happening?**
    *   `--build`: Docker Compose reads the `Dockerfile`, builds your Python application into a container image, and also downloads the official images for PostgreSQL and Redis.
    *   `up`: It then starts three containers based on these images and connects them to a shared virtual network.
*   **Expected Output:** You will see a stream of logs from all three services (`db`, `redis`, and `bot`). Wait until the log output stabilizes. You might see some database initialization messages.

### 2.2. Applying Database Migrations (First Time Only)

The first time you start the services, the `db` container creates an empty database. You need to apply our project's database schema to it.

1.  **Open a new terminal window** (leave the `docker-compose` one running).
2.  **List the running containers** to find the name of your bot container. It is usually `stocker-bot-1` or similar.
    ```bash
    docker ps
    ```
3.  **Execute the `alembic upgrade head` command** inside the running bot container. Replace `stocker-bot-1` with the actual name from the previous command.
    ```bash
    docker exec -it stocker-bot-1 poetry run alembic upgrade head
    ```
    *   **What's happening?**
        *   `docker exec -it`: This command allows you to run a command inside a running container.
        *   `poetry run alembic upgrade head`: Inside the container, we use `poetry run` to execute the `alembic` tool, telling it to apply all available migration scripts (in our case, the one that creates the `users` table).
    *   **Expected Output:** You should see logs from Alembic indicating that it's running the migration and applying the changes.

### 2.3. Granting First Admin Privileges

Now that the bot is running and the database is set up, you need to grant your own user admin rights.

1.  **Find your bot on Telegram** and send it a message (any message, like `/start`). This action registers your user in the database.
2.  **Use the `/grant_admin` command:** As the Super Admin (defined in your `.env` file), you can now grant admin rights. Send this command to your bot:
    ```
    /grant_admin YOUR_TELEGRAM_USER_ID
    ```
    (Replace `YOUR_TELEGRAM_USER_ID` with the same ID you put in the `SUPER_ADMIN_TELEGRAM_ID` variable).
3.  The bot should reply confirming that admin privileges have been granted.

**Your application is now fully running, configured, and ready to use.** You can now use the admin-only commands like `/update` and `/set_symbol`.

### 2.4. Stopping the Services

To stop all the running services, press `Ctrl+C` in the terminal where `docker-compose up` is running. To remove the containers and the network, you can run:

```bash
docker-compose down
```

---

## Part 3: Deploying to a VPS (The "100")

Deploying to a Virtual Private Server (VPS) follows almost the exact same steps as running locally, which is the power of Docker.

### 3.1. Server Preparation

1.  **Provision a VPS:** Get a new server from a cloud provider (e.g., DigitalOcean, Linode, AWS EC2).
2.  **Install Docker, Docker Compose, and Git:** Follow official guides to install these three tools on your server.

### 3.2. Deployment Steps

1.  **SSH into your VPS.**
2.  **Clone the repository.**
3.  **Create and configure the `.env` file** with your production secrets, just as you did locally.
4.  **Run the Application in Detached Mode:**
    ```bash
    docker-compose up --build -d
    ```
    *   `-d`: This crucial flag runs the containers in **detached mode**, meaning they will continue to run in the background after you log out.
5.  **Apply Database Migrations:**
    ```bash
    docker exec -it stocker-bot-1 poetry run alembic upgrade head
    ```

### 3.3. Managing the Live Application

*   **To view logs:** `docker-compose logs -f`
*   **To stop services:** `docker-compose down`
*   **To update the application:** Pull the latest code (`git pull`) and then run `docker-compose up --build -d` again. Docker will recreate only the services that have changed.

---

## Appendix A: Understanding GitHub Actions

We have a Continuous Integration (CI) pipeline configured in `.github/workflows/ci.yml`. This pipeline acts as an automated quality gate whenever you push code.

It automatically performs: **Dependency Installation**, **Linting**, **Testing**, **Security Scanning**, and **Docker Build Validation**.

As a developer, your workflow is:
1.  Create a new branch for your feature.
2.  Push your code to GitHub.
3.  Open a Pull Request.
4.  Check for a **green checkmark** on the Pull Request page, indicating all automated checks have passed.
5.  Merge your code.

This process ensures that the `main` branch always remains stable and high-quality.
